module.exports = {
    Student: require('./student.controller'),
    Course: require('./course.controller'),
    Registration: require('./registration.controller')
}